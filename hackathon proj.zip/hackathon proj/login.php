<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
</head>
<body>
<?php
if(isset($_GET['uname']) && isset($_GET['upwd'])) {
    $username = $_GET['uname'];
    $password = $_GET['upwd'];
    echo "<h1>Successfully logged in!</h1>";
    echo "<p>Username: $username</p>";
    echo "<p>Password: $password</p>";
} else {
    echo "<h1>Login failed!</h1>";
}
?>
</body>
</html>
