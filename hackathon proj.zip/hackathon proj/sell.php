<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $price = $_POST['price'];
    $condition = $_POST['condition'];
    $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO books (title, author, price, condition, user_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssisi", $title, $author, $price, $condition, $user_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header("Location: browse.html");
    exit;
}
?>
