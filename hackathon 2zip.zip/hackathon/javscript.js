document.getElementById('signupForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const response = await fetch('api/signup.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ email, password })
  });
  const data = await response.json();
  console.log(data);
});

document.getElementById('signinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const response = await fetch('api/signin.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ email, password })
  });
  const data = await response.json();
  console.log(data);
  if (data.success) {
    window.location.href = 'reports.html';
  }
});

document.getElementById('reportForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const response = await fetch('api/add_report.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': Bearer ${localStorage.getItem('token')}
    },
    body: JSON.stringify({ title, description })
  });
  const data = await response.json();
  console.log(data);
  if (data.success) {
    const reportsList = document.getElementById('reportsList');
    const newReport = document.createElement('li');
    newReport.textContent = ${data.report.title}: ${data.report.description};
    reportsList.appendChild(newReport);
  }
});