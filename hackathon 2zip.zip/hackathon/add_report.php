<?php
include 'db.php';
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);
$title = $data['title'];
$description = $data['description'];

$sql = "INSERT INTO reports (title, description) VALUES ('$title', '$description')";
if ($conn->query($sql) === TRUE) {
  $report = ['id' => $conn->insert_id, 'title' => $title, 'description' => $description];
  echo json_encode(['success' => true, 'report' => $report]);
} else {
  echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}
$conn->close();
?>