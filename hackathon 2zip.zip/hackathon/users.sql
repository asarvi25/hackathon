INSERT INTO users (email, password) VALUES
('john.doe@example.com', '$2y$10$E9QK4b1lPlNzpjxhbWq.7uQ4QnJfhU7c.IhS1lC/OUpV3/SXZpi8G'), -- password: password123
('jane.smith@example.com', '$2y$10$TKh8H1pbGJ/Q3X9OnU7i.e.zj8uI0/pPeW1/1Z.2NksVgl8g6Y1Ba'), -- password: mypassword
('mike.jones@example.com', '$2y$10$7QFhtz9/3D8QHgIk58Z7QOBNC8LsI32jBqz/W1vXM5hKjZxWFSrM6'), -- password: secretpass
('anna.brown@example.com', '$2y$10$5cFzzXn4/JztS3nOxnD1i.CxvY7O/xV5ZkZXktG1D0mRlb/Joa7mK'), -- password: anna123
('lucas.wilson@example.com', '$2y$10$3aQ0/zZ.8GnJeQ.yX6W0EOoBl7DIsmQ2xIm6U0hLwr8oyr1IHJs/6'); -- password: lucaspass
