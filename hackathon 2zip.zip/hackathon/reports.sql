INSERT INTO reports (title, description) VALUES
('Reduce Plastic Usage', 'Implemented a new policy to reduce plastic usage by 50% in our office.'),
('Recycling Drive', 'Organized a community recycling drive and collected over 200 pounds of recyclable materials.'),
('Compost Bin Setup', 'Set up a compost bin in the community garden to reduce organic waste.'),
('Paperless Initiative', 'Started a paperless initiative in our office to cut down on paper waste.'),
('Electronic Waste Collection', 'Held an electronic waste collection event to properly dispose of old electronics.');
