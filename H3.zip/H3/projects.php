<?php
include 'db.php';

$sql = "SELECT title, description, link, image FROM projects";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='project'>";
        echo "<h2>" . $row["title"] . "</h2>";
        echo "<p>" . $row["description"] . "</p>";
        if ($row["link"]) {
            echo "<a href='" . $row["link"] . "'>View Project</a>";
        }
        if ($row["image"]) {
            echo "<img src='images/" . $row["image"] . "' alt='" . $row["title"] . "'>";
        }
        echo "</div>";
    }
    echo "<script>window.open('projects.php','_self')</script>";|
} else {
    echo "0 results";
}
$conn->close();
?>
